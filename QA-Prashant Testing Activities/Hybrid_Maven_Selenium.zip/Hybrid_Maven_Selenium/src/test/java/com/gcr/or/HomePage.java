package com.gcr.or;

import org.openqa.selenium.By;

public class HomePage {
	
	public static By menuAccount = By.xpath("//span[@class='user-message account-name']");
	public static By lnkLogout =By.xpath("//span[text()='Logout']");

}
